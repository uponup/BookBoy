//
//  UIViewController+AOP.m
//  BookBoy
//
//  Created by 龙格 on 2020/2/25.
//  Copyright © 2020 Paul Gao. All rights reserved.
//

#import "UIViewController+AOP.h"
#import <objc/runtime.h>


@implementation UIViewController (AOP)

+ (void)load {
    method_exchangeImplementations(class_getInstanceMethod([self class], @selector(viewDidLoad)),
                                   class_getInstanceMethod([self class], @selector(tm_viewDidLoad)));
}

- (void)tm_viewDidLoad {
    [self tm_viewDidLoad];
    if ((self.navigationController.viewControllers.count > 1 || self.navigationController.presentingViewController)  && !self.navigationItem.leftBarButtonItem && self.navigationItem.leftBarButtonItems.count == 0) {
        UIImage *image = [[UIImage imageNamed:@"nav_icon_back"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStylePlain target:self action:@selector(popBackAction)];
    }
}

- (void)popBackAction {
    if (self.navigationController.viewControllers.count > 1) {
        [self.navigationController popViewControllerAnimated:YES];
    }else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


@end
